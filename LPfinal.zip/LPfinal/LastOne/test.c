#include <stdio.h>
int main(){
 int a,b;
 a=3+5*6-4/2;
}
