# include < iostream >
 using namespace std ;
 int main ( ) 
 {
	int a = 5 ;
	double b = 6.0 ;
	double c = a + b ;

 } 
