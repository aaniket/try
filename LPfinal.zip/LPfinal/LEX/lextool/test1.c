#include<stdio.h>
#define long long ll
#include<stdlib.h>

int main(){
	"this is a test string written inside quotes "
	int a=5;
	float value=6.43;
	while(a!=10){
		a=(a+value)-value/2;

	}
/* this
is 
a 
multiline
test
comment*/
	return 0;
}